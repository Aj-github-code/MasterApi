<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Session;

class Roles extends Model
{
    use HasFactory;
    protected $table;
    public function __construct(array $attributes = array())
    {
        parent::__construct($attributes);
        
        // if(Session::get('company_name')){
            
        //     $this->table = Session::get('company_name').'_roles as roles';
        // } else {
        // }
            $this->table = 'roles';
    }
    // protected $table = "roles";
    protected $fillable = ['role_name','role_code','slug','is_active','created_at','modified_at'];
    
    public $timestamps = false;
    
    public function roleUsers(){
        return $this->hasOne(UserRole::class, 'role_id', 'id');
    }
}
